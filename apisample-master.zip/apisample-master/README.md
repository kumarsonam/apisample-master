# apisample
Sample project for the AnkiDroid API. 

Developers should see [the Wiki](https://github.com/ankidroid/Anki-Android/wiki/AnkiDroid-API) for info on how to use the API.

Users can install the app by getting an APK from [the release section](https://github.com/ankidroid/apisample/releases) to see the API in action.
